from __future__ import annotations

import argparse
from pathlib import Path

from processor import process_batch


def main() -> None:
    parser = argparse.ArgumentParser(description="Mint PDF Sorter CLI")
    parser.add_argument("--packing-slips", required=True, help="Packing slips PDF")
    parser.add_argument("--labels", nargs="+", required=True, help="One or more label PDFs")
    parser.add_argument("--preset", choices=["combine_labels", "sort_slips", "sort_labels", "sort_both"], default="sort_both")
    parser.add_argument("--out-dir", default="outputs", help="Output folder")
    args = parser.parse_args()

    outputs = process_batch(args.packing_slips, args.labels, Path(args.out_dir), args.preset)
    for name, path in outputs.items():
        print(f"{name}: {path}")


if __name__ == "__main__":
    main()
