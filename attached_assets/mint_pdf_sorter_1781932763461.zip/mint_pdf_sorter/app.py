from __future__ import annotations

import tempfile
from pathlib import Path

import streamlit as st

from processor import process_batch

st.set_page_config(page_title="Mint PDF Sorter", page_icon="📄", layout="centered")
st.title("Mint PDF Sorter")
st.write("Upload packing slips and shipping labels, choose a preset, then download processed files.")

preset_labels = {
    "combine_labels": "Combine labels only",
    "sort_slips": "Sort packing slips by Style → Color → Size → Order #",
    "sort_labels": "Sort labels to sorted packing slip order",
    "sort_both": "Sort both packing slips and labels",
}

preset = st.selectbox("Preset", options=list(preset_labels), format_func=lambda k: preset_labels[k])
packing_file = st.file_uploader("Packing slips PDF", type=["pdf"])
label_files = st.file_uploader("Shipping label PDF(s)", type=["pdf"], accept_multiple_files=True)

if st.button("Process files", type="primary"):
    if preset in {"sort_slips", "sort_labels", "sort_both"} and not packing_file:
        st.error("Upload the packing slips PDF.")
        st.stop()
    if preset in {"combine_labels", "sort_labels", "sort_both"} and not label_files:
        st.error("Upload at least one shipping label PDF.")
        st.stop()

    with tempfile.TemporaryDirectory() as tmp:
        tmpdir = Path(tmp)
        packing_path = tmpdir / packing_file.name if packing_file else tmpdir / "blank.pdf"
        if packing_file:
            packing_path.write_bytes(packing_file.getbuffer())

        label_paths = []
        for f in label_files or []:
            p = tmpdir / f.name
            p.write_bytes(f.getbuffer())
            label_paths.append(p)

        with st.spinner("Processing PDFs..."):
            outputs = process_batch(packing_path, label_paths, tmpdir / "out", preset)

        st.success("Done")
        for key, path in outputs.items():
            label = {
                "combined_labels": "Download combined labels PDF",
                "sorted_packing_slips": "Download sorted packing slips PDF",
                "sorted_shipping_labels": "Download sorted shipping labels PDF",
                "match_report": "Download match report CSV",
                "zip": "Download all outputs ZIP",
            }.get(key, f"Download {path.name}")
            mime = "application/zip" if path.suffix == ".zip" else "text/csv" if path.suffix == ".csv" else "application/pdf"
            st.download_button(label, data=path.read_bytes(), file_name=path.name, mime=mime)
