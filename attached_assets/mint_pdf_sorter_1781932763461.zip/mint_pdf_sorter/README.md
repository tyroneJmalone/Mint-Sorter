# Mint PDF Sorter

Local web app for common production PDF workflows:

- Combine shipping label PDFs
- Sort packing slips by Style, Color, Size, then Order #
- Sort shipping labels to match the sorted packing slip sequence
- Export match/missing reports

## Install

```bash
cd mint_pdf_sorter
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
streamlit run app.py
```

The app opens in your browser. Upload a packing slip PDF and one or more label PDFs, choose a preset, then download the processed PDFs and reports.

## Matching logic

Packing slips are parsed for:

- Order number
- Customer/shipping name
- Style number
- Color
- Size

Labels are parsed for recipient name and address. Labels are matched to packing slips by normalized ship-to name first. A report is generated for matched, missing, and duplicate/unused labels.

## Notes

This is a first working version. For best accuracy, spot-check the match report after each batch, especially when two orders ship to the same recipient or one order contains multiple shippable packages.
